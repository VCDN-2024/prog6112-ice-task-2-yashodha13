/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patient;


import java.util.ArrayList;
import java.util.Scanner;

// Base class for Patient
class Patient {
    protected String name;
    protected int age;
    protected String gender;

    // Constructor for Patient
    public Patient(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    // Method to display patient information
    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age + ", Gender: " + gender);
    }
    
    // Eligibility check (to be overridden in subclasses)
    public void checkEligibility() {
        // This method is overridden in Male and Female classes
    }
}

// Subclass for Female patients
class Female extends Patient {

    // Constructor for Female class
    public Female(String name, int age) {
        super(name, age, "Female");
    }

    @Override
    public void checkEligibility() {
        if (age < 18) {
            System.out.println(name + " is not eligible for treatment at the emergency room, refer to DBN Hospital.");
        } else {
            System.out.println(name + " is eligible for treatment at DBN Hospital.");
        }
    }
}

// Subclass for Male patients
class Male extends Patient {
    private boolean hasChronicDisorder;

    // Constructor for Male class
    public Male(String name, int age, boolean hasChronicDisorder) {
        super(name, age, "Male");
        this.hasChronicDisorder = hasChronicDisorder;
    }

    @Override
    public void checkEligibility() {
        if (age > 18) {
            if (hasChronicDisorder) {
                System.out.println(name + " has a chronic disorder and will be transferred to JHB Hospital.");
            } else {
                System.out.println(name + " is eligible for treatment at DBN Hospital.");
            }
        } else {
            System.out.println(name + " is not eligible for treatment.");
        }
    }
}

// Main class for the program
public class PatientManagementSystem {

    // Mock data for patients
    static ArrayList<Patient> patients = new ArrayList<>();

    static {
        // Add mock data to the system
        patients.add(new Female("Sarah", 20));
        patients.add(new Female("Lisa", 17));
        patients.add(new Male("John", 25, false));
        patients.add(new Male("Tom", 19, true));
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Phase 1: User login
        try {
            System.out.println("Enter Username: ");
            String username = scanner.nextLine();
            System.out.println("Enter Password: ");
            String password = scanner.nextLine();

            if (!login(username, password)) {
                throw new Exception("Invalid credentials!");
            }

            System.out.println("Login successful!");

            // Phase 2: Search for patient by name
            System.out.println("Enter patient name to search: ");
            String searchName = scanner.nextLine();

            boolean found = false;
            for (Patient patient : patients) {
                if (patient.name.equalsIgnoreCase(searchName)) {
                    patient.displayInfo();
                    patient.checkEligibility();
                    found = true;
                    break;
                }
            }

            if (!found) {
                System.out.println("Patient not found.");
            }

            // Optional: Display all patients
            System.out.println("\n--- All Patients ---");
            for (Patient patient : patients) {
                patient.displayInfo();
                patient.checkEligibility();
            }

        } catch (Exception e) {
            System.out.println(e.getMessage()); // Display error message for invalid credentials
        } finally {
            scanner.close();
        }
    }

    // Method for user login
    public static boolean login(String username, String password) {
        return username.equals("Admin") && password.equals("St@a77");
    }
}
